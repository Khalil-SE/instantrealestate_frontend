import CreateEditInstaBot from "./CreateEditInstaBot";
import InstaBotManagement from "./InstaBotManagement";


export {CreateEditInstaBot, InstaBotManagement};