import PropertyManagement from "./PropertyManagement";

export {PropertyManagement};