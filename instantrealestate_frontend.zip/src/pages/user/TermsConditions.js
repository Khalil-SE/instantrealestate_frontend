import React from "react";

const TermsConditions = () => {
    return (
        <div className="terms-conditions">
        <h1>Terms and Conditions</h1>
        <p>Welcome to our Terms and Conditions page!</p>
        <p>Please read these terms carefully before using our service.</p>
        {/* Add your terms and conditions content here */}
        </div>
    );
    }   
export default TermsConditions;