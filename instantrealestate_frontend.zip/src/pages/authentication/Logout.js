import React from "react";      
import LogoutContent from "../../components/Authentication/LogoutContent";

const Logout = () => {
  return (
    <>
      <LogoutContent />
    </>
  );
};

export default Logout;
