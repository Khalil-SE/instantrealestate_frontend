import React from "react";   
import ResetPasswordForm from "../../components/Authentication/ResetPasswordForm";

const ResetPassword = () => {
  return (
    <>
      <ResetPasswordForm />
    </>
  );
};

export default ResetPassword;
