import React from "react";     
import LockScreenForm from "../../components/Authentication/LockScreenForm";

const LockScreen = () => {
  return (
    <>
      <LockScreenForm />
    </>
  );
};

export default LockScreen;
